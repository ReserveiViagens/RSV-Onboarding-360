from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class UserBase(BaseModel):
    email: EmailStr
    full_name: str

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = None

class User(UserBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True 

# Base schemas para Ticket e Attraction
class TicketBase(BaseModel):
    event_name: str
    event_date: datetime
    price: float
    customer_id: Optional[int]

# Ticket schema
class Ticket(BaseModel):
    id: int
    event_name: str
    event_date: datetime
    price: float
    customer_id: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True

class TicketCreate(TicketBase):
    pass

class AttractionBase(BaseModel):
    name: str
    description: str
    location: str

# Attraction schema
class Attraction(BaseModel):
    id: int
    name: str
    description: str
    location: str
    created_at: datetime

    class Config:
        from_attributes = True

class AttractionCreate(AttractionBase):
    pass 